<?php
error_reporting(E_ALL);

define('APP_KEY', 'YOUR_APP_KEY');
define('APP_SECRET', 'YOUR_APP_SECRET');
define('APP_ID', 'YOUR_APP_ID');
?>